CREATE DATABASE notes_app;

USE notes_app;

CREATE TABLE notes (
    id integer PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    contents TEXT NOT NULL,
    created TIMESTAMP NOT NULL DEFAULT NOW()
);

INSERT INTO
    notes (title, contents)
VALUES
    ('My First Note', "A note about something");

-- mysql schema example for creating a database and table
-- can paste this into mysql command line